/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.34.0.7242.6b8819789 modeling language!*/

package TeeTimeFinder;

// line 19 "../../model.ump"
// line 61 "../../model.ump"
public class CourseAdminAccount extends UserAccount
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public CourseAdminAccount(int aId, String aEmail, String aPassword)
  {
    super(aId, aEmail, aPassword);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}